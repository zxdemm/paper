package hk.polyu.comp.jaid.fixer.config;

/**
 * Created by Max PEI.
 */
public enum FailureHandling{
    CONTINUE, BREAK
}

